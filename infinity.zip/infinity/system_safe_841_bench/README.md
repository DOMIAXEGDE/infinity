Created the PowerShell 7 script here: [install_compile_run_gcc.ps1](sandbox:/mnt/data/install_compile_run_gcc.ps1)

It is set up to:

* detect `gcc` first
* try automatic installation via WinGet, MSYS2 `pacman`, Chocolatey, and Scoop
* compile every `.c` file in the target folder into `.exe`
* run each compiled `.exe` automatically
* place builds in a `build` folder

The install logic is based on current MSYS2 guidance: MSYS2 documents CLI-capable installation, recommends installing `mingw-w64-ucrt-x86_64-gcc`, and notes that updates are handled through `pacman -Suy`. I also included a WinGet WinLibs attempt because that package id is used in a current Windows GCC build workflow. ([MSYS2][1])

I set the default automated run input to `3` then `0`, because your uploaded C programs are menu-driven `012 generator` executables where option `3` generates output and `0` exits; that allows them to run non-interactively after compilation.  

Typical usage:

```powershell
pwsh .\install_compile_run_gcc.ps1 -SourceDir "D:\infinity\system_safe_841_bench"
```

Useful variants:

```powershell
pwsh .\install_compile_run_gcc.ps1 -SourceDir "C:\path\to\your\c\files" -SkipRun
pwsh .\install_compile_run_gcc.ps1 -SourceDir "C:\path\to\your\c\files" -RunInput "3`n0`n"
pwsh .\install_compile_run_gcc.ps1 -SourceDir "C:\path\to\your\c\files" -RunExistingExeOnly
```

I could not execute or validate the script here because this environment does not have PowerShell available.

[1]: https://www.msys2.org/ "MSYS2"
