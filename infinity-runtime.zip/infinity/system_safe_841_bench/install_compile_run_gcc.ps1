#requires -Version 7.0
[CmdletBinding()]
param(
    [string]$SourceDir = ".",
    [string]$BuildDir = "",
    [string[]]$Patterns = @("*.c"),
    [string]$RunInput = "3`n0`n",
    [int]$RunTimeoutSec = 20,
    [switch]$SkipRun,
    [switch]$RunExistingExeOnly
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Write-Section {
    param([string]$Text)
    Write-Host "`n=== $Text ===" -ForegroundColor Cyan
}

function Refresh-ProcessPath {
    $parts = @(
        [Environment]::GetEnvironmentVariable('Path', 'Process'),
        [Environment]::GetEnvironmentVariable('Path', 'User'),
        [Environment]::GetEnvironmentVariable('Path', 'Machine')
    ) -join ';'

    $env:Path = (($parts -split ';' | Where-Object { $_ -and $_.Trim() } | Select-Object -Unique) -join ';')
}

function Get-GccPath {
    $candidates = @(
        'gcc.exe',
        'x86_64-w64-mingw32-gcc.exe',
        'C:\msys64\ucrt64\bin\gcc.exe',
        'C:\msys64\mingw64\bin\gcc.exe',
        'C:\WinLibs\mingw64\bin\gcc.exe',
        'C:\WinLibs\bin\gcc.exe',
        "$env:ProgramFiles\WinLibs\mingw64\bin\gcc.exe",
        "$env:ProgramFiles\WinLibs\bin\gcc.exe"
    )

    foreach ($candidate in $candidates) {
        if ($candidate -match '^[A-Za-z]:\\') {
            if (Test-Path -LiteralPath $candidate) {
                return (Resolve-Path -LiteralPath $candidate).Path
            }
        }
        else {
            $cmd = Get-Command $candidate -ErrorAction SilentlyContinue
            if ($cmd) {
                return $cmd.Source
            }
        }
    }

    return $null
}

function Invoke-InstallAttempt {
    param(
        [string]$Label,
        [scriptblock]$Script
    )

    try {
        Write-Section $Label
        & $Script
    }
    catch {
        Write-Warning "${Label} failed: $($_.Exception.Message)"
    }

    Refresh-ProcessPath
    return (Get-GccPath)
}

function Install-GccIfNeeded {
    Refresh-ProcessPath
    $gcc = Get-GccPath
    if ($gcc) { return $gcc }

    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if ($winget) {
        $gcc = Invoke-InstallAttempt -Label 'Trying WinGet: WinLibs MinGW-w64' -Script {
            & $winget.Source install --id BrechtSanders.WinLibs.MCF.UCRT -e --accept-package-agreements --accept-source-agreements --silent
            if ($LASTEXITCODE -ne 0) { throw "winget install returned exit code $LASTEXITCODE" }
        }
        if ($gcc) { return $gcc }

        $gcc = Invoke-InstallAttempt -Label 'Trying WinGet: MSYS2' -Script {
            & $winget.Source install --id MSYS2.MSYS2 -e --accept-package-agreements --accept-source-agreements --silent
            if ($LASTEXITCODE -ne 0) { throw "winget install returned exit code $LASTEXITCODE" }
        }
        if ($gcc) { return $gcc }
    }

    $msysBashCandidates = @(
        'C:\msys64\usr\bin\bash.exe',
        "$env:ProgramFiles\MSYS2\usr\bin\bash.exe"
    )
    $msysBash = $msysBashCandidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1

    if ($msysBash) {
        $gcc = Invoke-InstallAttempt -Label 'Trying MSYS2 pacman install of GCC' -Script {
            & $msysBash -lc 'pacman --noconfirm -Suy'
            & $msysBash -lc 'pacman --noconfirm -S --needed mingw-w64-ucrt-x86_64-gcc'
            if ($LASTEXITCODE -ne 0) { throw "pacman returned exit code $LASTEXITCODE" }
        }
        if ($gcc) { return $gcc }

        if (Test-Path -LiteralPath 'C:\msys64\ucrt64\bin\gcc.exe') {
            return 'C:\msys64\ucrt64\bin\gcc.exe'
        }
        if (Test-Path -LiteralPath 'C:\msys64\mingw64\bin\gcc.exe') {
            return 'C:\msys64\mingw64\bin\gcc.exe'
        }
    }

    $choco = Get-Command choco.exe -ErrorAction SilentlyContinue
    if ($choco) {
        $gcc = Invoke-InstallAttempt -Label 'Trying Chocolatey: mingw' -Script {
            & $choco.Source install mingw -y --no-progress
            if ($LASTEXITCODE -ne 0) { throw "choco install returned exit code $LASTEXITCODE" }
        }
        if ($gcc) { return $gcc }
    }

    $scoop = Get-Command scoop -ErrorAction SilentlyContinue
    if ($scoop) {
        $gcc = Invoke-InstallAttempt -Label 'Trying Scoop: gcc' -Script {
            & $scoop.Source install gcc
            if ($LASTEXITCODE -ne 0) { throw "scoop install returned exit code $LASTEXITCODE" }
        }
        if ($gcc) { return $gcc }
    }

    throw @"
Unable to find or install GCC automatically.

Tried, in order:
- existing PATH / common locations
- winget WinLibs
- winget MSYS2
- MSYS2 pacman
- Chocolatey mingw
- Scoop gcc

Install one of them manually, then rerun this script.
"@
}

function Get-SourceFiles {
    param(
        [string]$Dir,
        [string[]]$SearchPatterns
    )

    $all = foreach ($pattern in $SearchPatterns) {
        Get-ChildItem -Path $Dir -Filter $pattern -File -ErrorAction SilentlyContinue
    }

    return $all | Sort-Object FullName -Unique
}

function Compile-Sources {
    param(
        [string]$Gcc,
        [System.IO.FileInfo[]]$Sources,
        [string]$OutDir
    )

    $compiled = New-Object System.Collections.Generic.List[string]
    $failed = New-Object System.Collections.Generic.List[string]

    foreach ($src in $Sources) {
        $exePath = Join-Path $OutDir (([IO.Path]::GetFileNameWithoutExtension($src.Name)) + '.exe')
        Write-Section "Compiling $($src.Name)"

        & $Gcc -std=c11 -O2 -Wall -Wextra $src.FullName -o $exePath
        if ($LASTEXITCODE -ne 0) {
            Write-Warning "Compile failed: $($src.FullName)"
            $failed.Add($src.FullName)
            continue
        }

        $compiled.Add($exePath)
        Write-Host "Built: $exePath" -ForegroundColor Green
    }

    [pscustomobject]@{
        Compiled = $compiled
        Failed   = $failed
    }
}

function Run-Executable {
    param(
        [string]$ExePath,
        [AllowNull()][string]$InputText,
        [int]$TimeoutSec
    )

    Write-Section "Running $(Split-Path -Leaf $ExePath)"

    if ($null -ne $InputText) {
        $psi = [System.Diagnostics.ProcessStartInfo]::new()
        $psi.FileName = $ExePath
        $psi.WorkingDirectory = (Split-Path -Parent $ExePath)
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow = $true
        $psi.RedirectStandardInput = $true
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError = $true

        $proc = [System.Diagnostics.Process]::new()
        $proc.StartInfo = $psi
        $null = $proc.Start()

        $proc.StandardInput.Write($InputText)
        $proc.StandardInput.Close()

        if (-not $proc.WaitForExit($TimeoutSec * 1000)) {
            try { $proc.Kill($true) } catch {}
            throw "Timed out after $TimeoutSec seconds: $ExePath"
        }

        $stdout = $proc.StandardOutput.ReadToEnd()
        $stderr = $proc.StandardError.ReadToEnd()

        if ($stdout.Trim()) { Write-Host $stdout.TrimEnd() }
        if ($stderr.Trim()) { Write-Warning $stderr.TrimEnd() }

        if ($proc.ExitCode -ne 0) {
            throw "Program exited with code $($proc.ExitCode): $ExePath"
        }
    }
    else {
        & $ExePath
        if ($LASTEXITCODE -ne 0) {
            throw "Program exited with code $($LASTEXITCODE): $ExePath"
        }
    }
}

$resolvedSourceDir = (Resolve-Path -LiteralPath $SourceDir).Path
if (-not $BuildDir) {
    $BuildDir = Join-Path $resolvedSourceDir 'build'
}

New-Item -ItemType Directory -Path $BuildDir -Force | Out-Null

$gcc = Install-GccIfNeeded
Write-Section 'Compiler'
Write-Host "Using GCC: $gcc" -ForegroundColor Yellow
& $gcc --version

$exeFiles = @()

if (-not $RunExistingExeOnly) {
    $sources = Get-SourceFiles -Dir $resolvedSourceDir -SearchPatterns $Patterns
    if (-not $sources -or $sources.Count -eq 0) {
        throw "No matching C source files found in: $resolvedSourceDir"
    }

    Write-Section 'Sources found'
    $sources | ForEach-Object { Write-Host $_.FullName }

    $buildResult = Compile-Sources -Gcc $gcc -Sources $sources -OutDir $BuildDir
    $exeFiles = @($buildResult.Compiled)

    if ($buildResult.Failed.Count -gt 0) {
        Write-Warning ("Failed to compile {0} file(s)." -f $buildResult.Failed.Count)
    }
}
else {
    $exeFiles = @(Get-ChildItem -Path $BuildDir -Filter '*.exe' -File -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FullName)
}

if (-not $exeFiles -or $exeFiles.Count -eq 0) {
    throw "No executables available to run in: $BuildDir"
}

if (-not $SkipRun) {
    foreach ($exe in $exeFiles) {
        try {
            Run-Executable -ExePath $exe -InputText $RunInput -TimeoutSec $RunTimeoutSec
        }
        catch {
            Write-Warning $_.Exception.Message
        }
    }
}

Write-Section 'Summary'
Write-Host ("Executables ready: {0}" -f $exeFiles.Count) -ForegroundColor Green
$exeFiles | ForEach-Object { Write-Host $_ }
Write-Host "Build directory: $BuildDir" -ForegroundColor Green

