Created the PowerShell 7 script here: [install_compile_run_gcc.ps1](sandbox:/mnt/data/install_compile_run_gcc.ps1)

It is set up to:

* detect `gcc` first
* try automatic installation via WinGet, MSYS2 `pacman`, Chocolatey, and Scoop
* compile every `.c` file in the target folder into `.exe`
* run each compiled `.exe` automatically
* place builds in a `build` folder

The install logic is based on current MSYS2 guidance: MSYS2 documents CLI-capable installation, recommends installing `mingw-w64-ucrt-x86_64-gcc`, and notes that updates are handled through `pacman -Suy`. I also included a WinGet WinLibs attempt because that package id is used in a current Windows GCC build workflow. ([MSYS2][1])

I set the default automated run input to `3` then `0`, because your uploaded C programs are menu-driven `012 generator` executables where option `3` generates output and `0` exits; that allows them to run non-interactively after compilation.  

Typical usage:

```powershell
pwsh .\install_compile_run_gcc.ps1 -SourceDir "D:\infinity\system_safe_841_bench"
```

Useful variants:

```powershell
pwsh .\install_compile_run_gcc.ps1 -SourceDir "C:\path\to\your\c\files" -SkipRun
pwsh .\install_compile_run_gcc.ps1 -SourceDir "C:\path\to\your\c\files" -RunInput "3`n0`n"
pwsh .\install_compile_run_gcc.ps1 -SourceDir "C:\path\to\your\c\files" -RunExistingExeOnly
```

I could not execute or validate the script here because this environment does not have PowerShell available.

[1]: https://www.msys2.org/ "MSYS2"

expectation ...

PS D:\infinity\system_safe_841_bench> .\install_compile_run_gcc.ps1 -SourceDir "D:\infinity\system_safe_841_bench"

=== Compiler ===
Using GCC: C:\msys64\mingw64\bin\gcc.exe
gcc.exe (Rev11, Built by MSYS2 project) 15.2.0
Copyright (C) 2025 Free Software Foundation, Inc.
This is free software; see the source for copying conditions.  There is NO
warranty; not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.


=== Sources found ===
D:\infinity\system_safe_841_bench\system_safe_841_1.c
D:\infinity\system_safe_841_bench\system_safe_841_2.c
D:\infinity\system_safe_841_bench\system_safe_841_3.c
D:\infinity\system_safe_841_bench\system_safe_841_4.c
D:\infinity\system_safe_841_bench\system_safe_841_5.c
D:\infinity\system_safe_841_bench\system_safe_841_6.c
D:\infinity\system_safe_841_bench\system_safe_841_7.c
D:\infinity\system_safe_841_bench\system_safe_841_8.c
D:\infinity\system_safe_841_bench\system_safe_841_9.c

=== Compiling system_safe_841_1.c ===
Built: D:\infinity\system_safe_841_bench\build\system_safe_841_1.exe

=== Compiling system_safe_841_2.c ===
Built: D:\infinity\system_safe_841_bench\build\system_safe_841_2.exe

=== Compiling system_safe_841_3.c ===
Built: D:\infinity\system_safe_841_bench\build\system_safe_841_3.exe

=== Compiling system_safe_841_4.c ===
Built: D:\infinity\system_safe_841_bench\build\system_safe_841_4.exe

=== Compiling system_safe_841_5.c ===
Built: D:\infinity\system_safe_841_bench\build\system_safe_841_5.exe

=== Compiling system_safe_841_6.c ===
Built: D:\infinity\system_safe_841_bench\build\system_safe_841_6.exe

=== Compiling system_safe_841_7.c ===
Built: D:\infinity\system_safe_841_bench\build\system_safe_841_7.exe

=== Compiling system_safe_841_8.c ===
Built: D:\infinity\system_safe_841_bench\build\system_safe_841_8.exe

=== Compiling system_safe_841_9.c ===
Built: D:\infinity\system_safe_841_bench\build\system_safe_841_9.exe

=== Running system_safe_841_1.exe ===

[012 generator]
1 length (1)
2 file (system_saf1.txt)
3 generate
0 exit
> done

[012 generator]
1 length (1)
2 file (system_saf1.txt)
3 generate
0 exit
>

=== Running system_safe_841_2.exe ===

[012 generator]
1 length (2)
2 file (system_saf2.txt)
3 generate
0 exit
> done

[012 generator]
1 length (2)
2 file (system_saf2.txt)
3 generate
0 exit
>

=== Running system_safe_841_3.exe ===

[012 generator]
1 length (3)
2 file (system_saf3.txt)
3 generate
0 exit
> done

[012 generator]
1 length (3)
2 file (system_saf3.txt)
3 generate
0 exit
>

=== Running system_safe_841_4.exe ===

[012 generator]
1 length (4)
2 file (system_saf4.txt)
3 generate
0 exit
> done

[012 generator]
1 length (4)
2 file (system_saf4.txt)
3 generate
0 exit
>

=== Running system_safe_841_5.exe ===

[012 generator]
1 length (5)
2 file (system_saf5.txt)
3 generate
0 exit
> done

[012 generator]
1 length (5)
2 file (system_saf5.txt)
3 generate
0 exit
>

=== Running system_safe_841_6.exe ===

[012 generator]
1 length (6)
2 file (system_saf6.txt)
3 generate
0 exit
> done

[012 generator]
1 length (6)
2 file (system_saf6.txt)
3 generate
0 exit
>

=== Running system_safe_841_7.exe ===

[012 generator]
1 length (7)
2 file (system_saf7.txt)
3 generate
0 exit
> done

[012 generator]
1 length (7)
2 file (system_saf7.txt)
3 generate
0 exit
>

=== Running system_safe_841_8.exe ===

[012 generator]
1 length (8)
2 file (system_saf8.txt)
3 generate
0 exit
> done

[012 generator]
1 length (8)
2 file (system_saf8.txt)
3 generate
0 exit
>

=== Running system_safe_841_9.exe ===

[012 generator]
1 length (9)
2 file (system_saf9.txt)
3 generate
0 exit
> done

[012 generator]
1 length (9)
2 file (system_saf9.txt)
3 generate
0 exit
>

=== Summary ===
Executables ready: 9
D:\infinity\system_safe_841_bench\build\system_safe_841_1.exe
D:\infinity\system_safe_841_bench\build\system_safe_841_2.exe
D:\infinity\system_safe_841_bench\build\system_safe_841_3.exe
D:\infinity\system_safe_841_bench\build\system_safe_841_4.exe
D:\infinity\system_safe_841_bench\build\system_safe_841_5.exe
D:\infinity\system_safe_841_bench\build\system_safe_841_6.exe
D:\infinity\system_safe_841_bench\build\system_safe_841_7.exe
D:\infinity\system_safe_841_bench\build\system_safe_841_8.exe
D:\infinity\system_safe_841_bench\build\system_safe_841_9.exe
Build directory: D:\infinity\system_safe_841_bench\build
PS D:\infinity\system_safe_841_bench>
